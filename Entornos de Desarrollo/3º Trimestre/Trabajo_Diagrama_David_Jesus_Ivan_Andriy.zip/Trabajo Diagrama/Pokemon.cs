﻿
namespace Model1
{
    class Pokemon
    {
        public string Nombre;                
        public int Energia;                
        public Tipo Tipo;                
        public string Habilidades;                
        
        

        
        
        public void Daño_recibido ()
        {
            
        }                    
        
        public void Atacar ()
        {
            
        }                    
    }
}
