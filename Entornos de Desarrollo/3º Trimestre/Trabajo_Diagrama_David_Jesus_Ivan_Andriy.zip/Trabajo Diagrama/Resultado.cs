﻿
namespace Model1
{
    class Resultado
    {
        public string NombreGanador;                
        public DateTime TiempoBatalla;                
        public object Energia;                
        
        

        
        
        public (type) method (object type)
        {
            
        }                    
    }
}
