﻿
namespace Model1
{
    class Caterpie : Pokemon
    {
        
        
        
        public (type) method (object type)
        {
            
        }                    
    }
}
