﻿
namespace Model1
{
    class Batalla
    {
        public DateTime Tiempo;                
        public int Turnos;                
        public object Pokemon;                
        
        

        
        
        public void Resultado ()
        {
            
        }                    
    }
}
