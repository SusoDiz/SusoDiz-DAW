﻿
namespace Model1
{
    class Tipo
    {
        public object Nombre;                
        public object Debilidad;                
        public object FactorDeDaño;                
        
        

        
        
        public (type) method (object type)
        {
            
        }                    
    }
}
