﻿
namespace Model1
{
    class Squartle : Pokemon
    {
        
        
        
        public (type) method (object type)
        {
            
        }                    
    }
}
