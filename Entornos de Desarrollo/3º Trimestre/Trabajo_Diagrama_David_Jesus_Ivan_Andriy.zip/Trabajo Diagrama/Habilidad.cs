﻿
namespace Model1
{
    class Habilidad
    {
        public object Nombre;                
        public object Daño;                
        
        

        
        
        public (type) method (object type)
        {
            
        }                    
    }
}
