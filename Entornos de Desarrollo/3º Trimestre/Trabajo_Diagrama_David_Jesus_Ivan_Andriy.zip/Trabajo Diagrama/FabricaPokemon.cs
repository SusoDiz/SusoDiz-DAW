﻿
namespace Model1
{
    class FabricaPokemon
    {
        
        
        
        public void FabricarPokemon ()
        {
            
        }                    
    }
}
