﻿
namespace Model1
{
    class Charmander : Pokemon
    {
        
        
        
        public (type) method (object type)
        {
            
        }                    
    }
}
